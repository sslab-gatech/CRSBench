/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.fontbox.ttf.model;

import java.util.List;
import java.util.Set;

import org.apache.fontbox.ttf.table.common.FeatureRecord;

/**
 * Models a {@link FeatureRecord}
 * 
 * @author Palash Ray
 *
 */
public interface ScriptFeature
{
    /**
     * The name of this feature.
     * 
     * @return 
     */
    String getName();

    /**
     * Returns a set of integer sequences that may match and thus can be replaced by
     * something else.
     *
     * @return
     */
    Set<List<Integer>> getAllGlyphIdsForSubstitution();

    /**
     * Returns true if the sequence of integers can be replaced by something else.
     * 
     * @param glyphIds sequence of integers
     * @return 
     */
    boolean canReplaceGlyphs(List<Integer> glyphIds);

    /**
     * Returns the replacement for the input sequence of integers.
     * 
     * @param glyphIds sequence of integers
     * @return 
     */
    List<Integer> getReplacementForGlyphs(List<Integer> glyphIds);

}
