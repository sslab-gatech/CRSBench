Fixes #9999.
